import { combineReducers } from "redux";
import {TokenReducer} from "./Login/Login.Reducer";
import { ParentReducer } from "./Parent/Parent.Reducer";
import{ChildReducer} from "./Child/Child.Reducer";
import { EnrollmentReducer } from "./Enrollment/Enrollment.Reducer";

export const rootReducer = combineReducers({
     Token :TokenReducer,
     ParentList:ParentReducer,
     ChildList:ChildReducer,
     EnrollmentList:EnrollmentReducer,
})
