import { createStore,applyMiddleware} from "redux";
import { rootReducer } from "./RootReducer";
import thunk from "redux-thunk";

const middleware =[thunk];

export const Store=createStore(
    rootReducer,applyMiddleware(...middleware)
)
