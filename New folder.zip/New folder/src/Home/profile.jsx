import { useEffect, useState } from "react";
import MainAxios from "../redux/Action";

const Profile = () => {

    const url = `https://localhost:7159/Account/GetUserProfile?token`

    const [Data, setdata] = useState({ username: "", email: " ", role: "" });

    useEffect(() => { MainAxios(url, "GET","").then(result => setdata(result),) }, [])

    return (
        <div style={{ alignItems: 'center', textAlign: "center", display: "flex" }}>
            <div style={{ borderStyle: "double", width: 500, marginLeft: 250 }}>
                <div style={{ paddingTop: 20 }}>
                    <img
                        width={90}
                        src="https://st3.depositphotos.com/15648834/17930/v/600/depositphotos_179308454-stock-illustration-unknown-person-silhouette-glasses-profile.jpg"
                    />
                </div>
                <div>
                    <div><h1 style={{ textAnchor: "middle", textJustify: "auto" }}>User Name  :  {Data.username} </h1></div>
                    <div><h1 style={{ textAnchor: "middle", textJustify: "auto" }}>User Email :  {Data.email} </h1></div>
                    <div><h1 style={{ paddingLeft: "5px", textAnchor: "middle", textJustify: "auto" }}>User Role  : {Data.role} </h1></div>
                </div>
            </div>
        </div>)
}
export default Profile;