import React from 'react';
import {
  HomeOutlined,
  UserOutlined,
  DashboardOutlined,
  UnorderedListOutlined,
  PoweroffOutlined,
  FormOutlined,
  UploadOutlined,
  UserAddOutlined,
  UsergroupAddOutlined,
  CheckCircleOutlined,
  CloseSquareOutlined
} from "@ant-design/icons";
import { Col, Layout, Menu, Row, theme } from 'antd';
import { Link } from 'react-router-dom';
const { Header, Content, Sider } = Layout;
const newnav = [];
const SideBar = ({ children }) => {

  var items = []
  if (localStorage.getItem("Role") === "Admin") 
  {
    items = [...navList1, ...navAdmin,...navList2];
  }
  else 
  {
    items = [...navList1,...navList2];
  }

  const { token: { colorBgContainer }, } = theme.useToken();

  return (
    <Layout>
      <Sider breakpoint="lg" collapsedWidth="0">
        <div>
          <Row className="logo">
            <Col span={6} style={{ paddingLeft: "10px" }}>
              <UserOutlined />
            </Col>
            <Col span={18} style={{ paddingLeft: "10px" }}>
              {localStorage.getItem("Username")}
            </Col>
          </Row>
        </div>
        <Menu
          theme="dark"
          mode="inline"
          defaultSelectedKeys={['10']}
          items={items.map(
            (item, index) => ({
              key: index,
              icon: item.icon,
              label: <Link to={item.key} >{item.label}</Link>,
              children: item.children
            }),
          )}
        />
      </Sider>
      <Layout>
        <Header  >
          {localStorage.getItem("Role") === "Customer" && <h1 style={{ color: "white", textAlign: "center" }}>Welcome To Child Care Management</h1>}

          {localStorage.getItem("Role") === "Admin" && <h1 style={{ color: "black", textAlign: "center" }}>
            <Row style={{ marginLeft: "110px" }}>
              <Col>
                <Link style={{ color: "white" }} to="/AdminSignUp"> <UserAddOutlined /> Create Admin</Link>
              </Col>
              <Col span={8}  >
                <Link style={{ color: "white" }} to="/GetenrollmentApproval"><UsergroupAddOutlined /> Approval Pending</Link>
              </Col>
              <Col>
                <Link style={{ color: "white" }} to="/ActiveChild"><CheckCircleOutlined /> Active Child's</Link>
              </Col>
            </Row>
          </h1>
          }
        </Header>
        <Content style={{ margin: '40px 16px 0', overflowY: "auto", overflowX: "auto", minHeight: 350 }}>
          <main style={{ padding: 24, background: colorBgContainer }}>{children}</main>
        </Content>
      </Layout>
    </Layout>
  );
};

export default SideBar;

const navAdmin = [
  {
    label: <h5>Enrollment Details</h5>, icon: <UnorderedListOutlined />,
    children: [
      { label: <Link to={"/ApprovalList"}>Approval Data</Link>, key: "/ApprovalList", icon: <CheckCircleOutlined /> },
      { label: <Link to={"/RejectedList"}>Rejected data</Link>, key: "/RejectedList", icon: <CloseSquareOutlined /> }
    ]
  },
  {label :<h5>Child's Profile</h5>,key: "/ChildProfile",icon :<UsergroupAddOutlined/>},
]

const navList1 = [
  { label: <h5>Home</h5>, key: "/home", icon: <HomeOutlined /> },
  {
    label: <h5>Registration</h5>, icon: <DashboardOutlined />,
    children: [
      { label: <Link to={"/PostParent"} >Parent Registration</Link>, icon: <FormOutlined />, subkey: 11 },
      { label: <Link to={"/PostChild"} >Child Registration</Link>, icon: <FormOutlined />, subkey: 12 },
      { label: <Link to={"/PostEnrollment"} >Enrollment Registration</Link>, icon: <FormOutlined />, subkey: 13 },
      { label: <Link to={"/FileUpload"}>Upload Image</Link>, icon: <UploadOutlined />, subkey: 14 }]
  },
  {
    label: <h5>Users List</h5>, icon: <UnorderedListOutlined />,
    children: [
      { label: <Link to={"/GetParentlist"} >Parent List</Link>, key: "/GetParentlist", icon: <UnorderedListOutlined /> },
      { label: <Link to={"/GetChilList"} >Child List</Link>, key: "/GetChilList", icon: <UnorderedListOutlined /> },
      { label: <Link to={"/GetEnrollmentList"} >Enrollment List</Link>, key: "/GetEnrollmentList", icon: <UnorderedListOutlined /> },
    ]
  },

]

const navList2 = [
{ label: <h5>Profile</h5>, key: "/profile", icon: <UserOutlined /> },

{ label: <h5>signout</h5>, key: "/logOut", icon: <PoweroffOutlined /> },
];