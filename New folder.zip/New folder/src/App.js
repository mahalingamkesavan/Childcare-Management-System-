import SingIn from "./Components/Authentication/SignIn"
import AdminSingUp from "./Components/Authentication//Admi_SignUp";
import SignUp from "./Components/Authentication//SignUp";
import LogOut from "./Components/Authentication/Logout";


import InsertParent from './Components/Parent-Data/PostParent';
import GetParentById from './Components/Parent-Data/GetParentbyId'
import { ParentComponent } from "./Components/Parent-Data/GetParentList";

import { ChilComponent } from './Components/Child-Data/GetChildList'
import InsertChild from './Components/Child-Data/PostChild'
import GetChildById from './Components/Child-Data/GetChildById';

import GetParentChild from './Components/ParentChild/ParentChild'
import InsertEnrollment from "./Components/Enrollment-Data/PostEnrollment"
import { GetEnrollmentList } from './Components/Enrollment-Data/EnrollmentList'
import { FileUpload } from "./Components/Enrollment-Data/FileUpload"
import GetEnrollmentApprovalList from "./Components/Enrollment-Data/GetEnrollmentApprovalPendingList";
import EnrollmentApprovalList from "./Components/Enrollment-Data/EnrollmentApprovalList"
import EnrollmentRejectedList from "./Components/Enrollment-Data/EnrollmentRejectedList"
import GetActiveChildCount from './Components/Enrollment-Data/GetActiveChildCount';
import GetActiveChild from './Components/Enrollment-Data/GetActiveChild';
import { GetChildProfile } from './Components/Enrollment-Data/ChildProfile';

import SideBar from "./Home/middlecomponent"
import { Route, Routes } from "react-router-dom";
import Home from './Home/Home';
import Profile from "./Home/profile"
import { Provider } from "react-redux";
import { Store } from "./redux/Store";
import PrivateRout from "./Home/protectedRoutes";
import { Result } from "antd";


function App() {
  return (
    <Provider store={Store}>
      <Routes>
        <Route path={"/"} element={<SingIn />} />
        <Route path={"/SignUp"} element={<SignUp />} />
        
        <Route element={<PrivateRout ></PrivateRout>}>
          <Route path={"/AdminSignUp"} element={<SideBar><AdminSingUp /></SideBar>} />
          <Route path={"/GetParentlist"} element={<SideBar><ParentComponent /></SideBar>} />
          <Route path={'/PostParent'} element={<SideBar><InsertParent /></SideBar>} />
          <Route path={'/GetParent'} element={<GetParentById />} />
          <Route path={'/GetChild'} element={<GetChildById />} />
          <Route path={'/GetChilList'} element={<SideBar><ChilComponent /></SideBar>} />
          <Route path={'/PostChild'} element={<SideBar><InsertChild /></SideBar>} />
          <Route path={'/ParentChild'} element={<GetParentChild />} />
          <Route path={'/PostEnrollment'} element={<SideBar><InsertEnrollment /></SideBar>} />
          <Route path={"/GetEnrollmentList"} element={<SideBar><GetEnrollmentList /></SideBar>} />
          <Route path={"/logOut"} element={<SideBar><LogOut /></SideBar>} />
          <Route path={"/home"} element={<SideBar><Home /></SideBar>} />
          <Route path={"/profile"} element={<SideBar><Profile /></SideBar>} />
          <Route path={"/GetParentChild/:Id"} element={<SideBar><GetParentChild /></SideBar>} />
          <Route path={"/FileUpload"} element={<SideBar><FileUpload /></SideBar>} />
          <Route path={"/GetenrollmentApproval"} element={<SideBar><GetEnrollmentApprovalList /></SideBar>} />
          <Route path={"/ApprovalList"} element={<SideBar><EnrollmentApprovalList /></SideBar>} />
          <Route path={"/RejectedList"} element={<SideBar><EnrollmentRejectedList /></SideBar>} />
          <Route path={'/ActiveChildCount'} element={<GetActiveChildCount />} />
          <Route path='/ActiveChild' element={<SideBar><GetActiveChild /></SideBar>} />
          <Route path='/ChildProfile' element={<SideBar><GetChildProfile /></SideBar>} />
        <Route path="*" element={<SideBar><Result status={404} title={'Sample by Kishore'} subTitle={'Hi from Kishore kumat K'}/></SideBar>}/>
        </Route>
        {/* <Route path="*" element={<Result status={404} title={'Sample by Kishore'} subTitle={'Hi from Kishore kumat K'}/>}/> */}
      </Routes>
    </Provider>
  )
}

export default App;














































