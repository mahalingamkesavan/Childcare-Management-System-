const Get ="GET";

const Put ="PUT";

const Post="POST";

const Delete="DELETE";

const HTTP_METHOD ={Get,Put,Post,Delete}

export default HTTP_METHOD;