
export const LoginAPILink=`https://localhost:7159/Account`;

export const ParentAPILink=`https://localhost:7232/Parent`;

export const ChildAPILink=`https://localhost:7232/Child`;

export const EnrollmentAPILink=`https://localhost:7232/Enrollment`;

export const FileUploadAPILink=`https://localhost:7232/Files`;