const Token ="Token";
const Role="Role";
const Username="Username";
const IsToken ="IsToken"

const StorageKey={Token,Role,Username,IsToken};
export default StorageKey;