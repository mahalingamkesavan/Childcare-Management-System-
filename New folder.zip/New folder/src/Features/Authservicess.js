import { toast } from "react-toastify";
import { LoginAPILink } from "../Variables/APIEndPoints";
import MainAxios from "../redux/Action";
import HTTP_METHOD from "../Variables/HTTPmethods";
import { FetchTokenRequest, fetchTokenSuccess, fetchTokenFailed } from "../redux/Login/Login.Action";
import StorageKey from "../Variables/LocalStorageKey";

const SuccessMessage = (e) => { toast.success(e) }; const ErrorMessage = (e) => { toast.error(e) };


export const LoginData = async (data, disPatch) => {

    disPatch(FetchTokenRequest()); const url = `${LoginAPILink}/login`; //const nav = useNavigate();

    await MainAxios(url, HTTP_METHOD.Post, data)
        .then(res => {
            disPatch(fetchTokenSuccess(res));
            localStorage.setItem(StorageKey.Token, res.token); localStorage.setItem(StorageKey.Role, res.roles);
            localStorage.setItem(StorageKey.Username, res.username);
            localStorage.setItem(StorageKey.IsToken, true);
        })
        .catch(res => {
            disPatch(fetchTokenFailed(res.response.data.message));
            ErrorMessage(res.response.data.message);
        })
}

export async function CreateNewUser(data) {

    const url = `${LoginAPILink}/Register-Employee`;
    var response;
    await MainAxios(url, HTTP_METHOD.Post, data)
        .then(res => {
            console.log(res.message);
            if (res.message === 'User created successfully!') {
                SuccessMessage(res.message);
                response = res.message
            }
        })
        .catch((error) => {

            ErrorMessage(error.response.data.Message);
            response = error.response.data.Message
        });

    return response;
}

export const CreateAdmin = async (data) => {

    const url = `${LoginAPILink}/register-admin`;

    await MainAxios(url, HTTP_METHOD.Post, data)

        .then(res => SuccessMessage(res.message))

        .catch((error) => { ErrorMessage(error.response.data.Message); })
}

export const createParentUser = async (data) => {

    const url = `${LoginAPILink}/Register-user`;

    await MainAxios(url, HTTP_METHOD.Post, data)

        .then(res => SuccessMessage(res.message))

        .catch((error) => { ErrorMessage(error.response.data.Message); })
}

