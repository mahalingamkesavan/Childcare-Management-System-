import { toast } from "react-toastify";
import { ParentAPILink } from "../Variables/APIEndPoints";
import MainAxios from "../redux/Action";
import HTTP_METHOD from "../Variables/HTTPmethods";
import { FetchParentRequest, fetchParentSuccess, fetchParentFailed } from "../redux/Parent/Parent.Action";
import { useState } from "react";

const SuccessMessage = (e) => { toast.success(e) }; const ErrorMessage = (e) => { toast.error(e) };

var response = "";

export const RegisterParent = async (data) => {

    const url = `${ParentAPILink}/RegistrationParent`;

    await MainAxios(url, HTTP_METHOD.Post, data)
        .then(res => {
            if (res.results.message === "registration_successfull") {
                SuccessMessage(res.results.message)
                localStorage.setItem("Parent Id", res.id);

                response = res.results.message;
            }
            else { ErrorMessage(res.results.message); response = res.results.message; }

        }).catch((error) => {
            if (error.response.data.Message === "Internal Server Error.") {
                ErrorMessage(error.response.data.Message);
                response="";
            }
            else {
                response="";
                PrintvalidationError(error.response.data.errors);
            }

        })
        return response;
}

const PrintvalidationError = (obj) => {
    for (var key in obj) {
        for (let i = 0; i < obj[key].length; i++) {
            ErrorMessage(obj[key][i])
        }
    }
    
}

export async function GetParentList(disPatch)
{
    var parentData=[]

    disPatch(FetchParentRequest());

    const url = `${ParentAPILink}/GetParentList`;

    await MainAxios(url, HTTP_METHOD.Get, "")
        .then(res => {
            parentData=res?.parent
            disPatch(fetchParentSuccess(res));
        })
        .catch((error) => { console.log(error); })
        // disPatch(fetchParentFailed(error.response.data.Message));
        return parentData;
}

