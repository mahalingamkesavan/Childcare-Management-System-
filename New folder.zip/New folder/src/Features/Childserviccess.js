import { toast } from "react-toastify";
import { ChildAPILink } from "../Variables/APIEndPoints";
import MainAxios from "../redux/Action";
import HTTP_METHOD from "../Variables/HTTPmethods";
import { FetchChildRequest, fetchChildSuccess, fetchchildFailed } from "../redux/Child/Child.Action";

const SuccessMessage = (e) => { toast.success(e) }; const ErrorMessage = (e) => { toast.error(e) };


export const GetChildList = async (disPatch) => {

    const url = `${ChildAPILink}/GetChildList`; var ChildData = [];

    disPatch(FetchChildRequest());

    await MainAxios(url, HTTP_METHOD.Get, "")

        .then(res => { disPatch(fetchChildSuccess(res?.childList)); ChildData = res?.childList })


        .catch((error) => { disPatch(fetchchildFailed(error)); ErrorMessage("Internal Server Error"); })

    return ChildData;
} 