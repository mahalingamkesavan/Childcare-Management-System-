import { toast } from "react-toastify";
import { EnrollmentAPILink } from "../Variables/APIEndPoints";
import MainAxios from "../redux/Action";
import HTTP_METHOD from "../Variables/HTTPmethods";
import {FetchEnrollmentRequest,fetchEnrollmentSuccess,fetchEnrollmentFailed} from "../redux/Enrollment/Enrollment.Action";

const SuccessMessage = (e) => { toast.success(e) }; const ErrorMessage = (e) => { toast.error(e) };

export const GetEnrollment = async (disPatch) => {

    const url = `${EnrollmentAPILink}/GetEnrollmentList`; var EnrollmentData = [];

    disPatch(FetchEnrollmentRequest());

    await MainAxios(url, HTTP_METHOD.Get, "")

        .then(res => { disPatch(fetchEnrollmentSuccess(res?.entrollmentslist)); EnrollmentData = res?.entrollmentslist })

        .catch((error) => { disPatch(fetchEnrollmentFailed(error.response.data.Message)); ErrorMessage(error.response.data.Message); })

    return EnrollmentData;
} 