import { Button, Modal } from 'antd';
import { useState } from 'react';
import { toast } from 'react-toastify';
import MainAxios from "../../redux/Action";
import HTTP_METHOD from "../../Variables/HTTPmethods";
import {ChildAPILink} from "../../Variables/APIEndPoints";

const DeleteChild = ({ record, records }) => {

  const { id } = records || {};

  const [isModalOpen, setIsModalOpen] = useState(false);

  const responce = (e) => { toast.success(e) };  const Errorresponse = (e) => toast.error(e);

  const showModal = () => { setIsModalOpen(true); };

  const handleOk = () => {
    if (localStorage.getItem("Role") === "Admin") 
    {
      const url = `${ChildAPILink}/DeleteChildById?id=${records.id}`
     
      MainAxios(url, HTTP_METHOD.Delete, "")

        .then(res => {
          if (res.results.message === "Delete_Successfull") 
          {
               responce(res.results.message)
               window.location.reload();
          }
          else 
          {
            responce(res.results.message)
          }
        }).catch((e) => Errorresponse(e.response.data.Message))
    }
    else {
      Errorresponse("Your Con't Access,Contact Admin....")
         }
    setIsModalOpen(false);
  }
  const handleCancel = () => { setIsModalOpen(false); };
  return (
    <>
      <Button type="primary" onClick={showModal}> Delete </Button>
      <Modal title="Delete Confirmation " open={isModalOpen} onOk={handleOk} onCancel={handleCancel}>
        <p>Are you sure delete this task?..</p>
      </Modal>
    </>
  );
}
export default DeleteChild
































    // const [data, setStatus] = useState("");
    // console.log(data);
    // useEffect(() => {
    //     // DELETE request using fetch with set headers
    //     const requestOptions = {
    //         method: 'DELETE',
    //         headers: {
    //             'Authorization': `Bearer ${localStorage.getItem("Token")}`,
    //             'My-Custom-Header': 'foobar'
    //         }
    //     };
    //     fetch(`https://localhost:7232/Child/DeleteChildById?id=8`, requestOptions)
    //         .then(async response => {
    //             const data = await response.json();
    //             console.log(data);
    //             // check for error response
    //             if (!response.ok) {
    //                 // get error message from body or default to response status
    //                 const error = (data && data.message) || response.status;
    //                 return Promise.reject(error);
    //             }
    //             setStatus('Delete successful');
    //         })

    // }, []);
