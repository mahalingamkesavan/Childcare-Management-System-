import React, { useEffect, useState } from 'react';
import DeleteChild from './DeleteChild';
import UpdatePopupChild from "./UpdatePopupChild"
import { Col, Row, Space, Table, Input } from 'antd';
import * as moment from "moment";
import { GetChildList } from "../../Features/Childserviccess";
import { useDispatch } from 'react-redux';


export const ChilComponent = () => {
 
  const [ChildData, SetChild] = useState([]);
  const [value, setValue] = useState('');
  const [dataSource, setDataSource] = useState([]);

  const disPatch=useDispatch();

  const columns = [
    { title: 'Child ID', dataIndex: 'id', key: 'id', },
    { title: 'Parent ID', dataIndex: 'parentID', key: 'parentID', },
    { title: 'Gender', dataIndex: 'gender', key: 'gender', },
    { title: 'Date Of Birth', key: 'dateOfBirth', dataIndex: 'dateOfBirth', render: (record) => (<span>{moment(record).format("DD-MM-YYYY")}</span>) },
    { title: 'First Name', key: 'firstName', dataIndex: 'firstName', },
    { title: 'Last Name', key: 'lastName', dataIndex: 'lastName', },
    { title: 'Status', key: 'status', dataIndex: 'status', },
    {
      title: 'Action', render: (record, records) => {
        return (
          <Row>
            <Space size={10}>
              <Col span={12}>
                {localStorage.getItem("Role") === "Admin" && <DeleteChild records={records} />}
              </Col>
              <Col span={12}>
                <UpdatePopupChild records={records} />
              </Col>
            </Space>
          </Row>)
      }
    }
  ];

useEffect (() => { GetChildList(disPatch).then((res)=>SetChild(res));},[]);

useEffect(() => { if (ChildData.length > 0) { setDataSource(ChildData) } }, [ChildData]);

return (<div>
  <input
    placeholder="Search Name ....."
    value={value}
    onChange={(e) => {
      const currValue = e.target.value;
      setValue(currValue);
      const filteredData = ChildData.filter(entry => entry.firstName.toLowerCase().includes(currValue));
      setDataSource(filteredData);
    }}
    style={{ marginBottom: 8,width:"200px"}}
  />
  <Table rowKey={record => record.id} columns={columns} dataSource={dataSource} />
</div>)
}
