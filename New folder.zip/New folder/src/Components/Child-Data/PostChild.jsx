import React, { useState } from "react";
import { ChildAPILink } from "../../Variables/APIEndPoints";
import { useNavigate } from 'react-router-dom';
import { toast } from 'react-toastify';
import MainAxios from "../../redux/Action";
import HTTP_METHOD from "../../Variables/HTTPmethods"
import 'react-toastify/dist/ReactToastify.css';

function InsertChild() {

    const url = `${ChildAPILink}/RegistrationChild`;

    const [Childdata, setChildData] = useState({ firstName: '', lastName: '', status: '', gender: '', dateOfBirth: '' })

    const nav = useNavigate();

    const SuccessMessage = (e) => { toast.success(e) }; const ErrorMessage = (e) => { toast.error(e) };

    function Submit(e) {

        e.preventDefault();
        MainAxios(url, HTTP_METHOD.Post, { ...Childdata, parentId: localStorage.getItem("Parent Id") })
            .then(res => {
                if (res.results.message === "registration_successfull") {
                    SuccessMessage(res.results.message);
                    localStorage.setItem("Child Id", res.id);
                    setTimeout(() => { nav("/PostEnrollment") }, 4000);
                }
                else { ErrorMessage(res.results.message); }
            })
            .catch((error) => {
                console.log(error.response.data.Message);
                if (error.response.data.Message === "Internal Server Error .") {
                    ErrorMessage(error.response.data.Message);
                }
                else {
                    PrintvalidationError(error.response.data.errors);
                }

            })
    }

    function handle(e) {
        const newdata = { ...Childdata }
        newdata[e.target.id] = e.target.value
        setChildData(newdata)
    }
    const PrintvalidationError = (obj) => {
        for (var key in obj) {
            for (let i = 0; i < obj[key].length; i++) {
                ErrorMessage(obj[key][i])
            }
        }
    }

    return (
        <div className="container">
            <div style={{ textAlign: "center" }}>
                <img
                    width={250}
                    src="https://1coresolution.com/images/1corelogo-opti.png" />
            </div>
            <div className="title">Registration Child</div>
            <div className="content">
                <form onSubmit={(e) => Submit(e)} action="#">
                    <div className="user-details">
                        <div className="input-box">
                            <span className="details">First Name</span>
                            <input type="text" onChange={(e) => handle(e)} id='firstName' value={Childdata.firstName} placeholder="Enter your name" required />
                        </div>
                        <div className="input-box">
                            <span className="details">Last Name</span>
                            <input type="text" onChange={(e) => handle(e)} id='lastName' value={Childdata.lastName} placeholder="Enter your lastname" required />
                        </div>
                        <div className="input-box">
                            <span className="details">Date Of Birth</span>
                            {console.log(Childdata.dateOfBirth)}
                            <input type='date' onChange={(e) => handle(e)} id='dateOfBirth' value={Childdata.dateOfBirth} required />
                        </div>
                        <div className="input-box">
                            <span className="details">Status </span>
                            <select type='text' className="classdropdown" onChange={(e) => handle(e)} id='status' value={Childdata.status}>
                                <option> Status</option>
                                <option value="Active">Active</option>
                                <option value="INActive">INActive</option>
                            </select>
                        </div>
                        <div className="input-box">
                            <span className="details">Gender </span>
                            <select type='text' className="classdropdown" onChange={(e) => handle(e)} id='gender' placeholder="Gender" value={Childdata.gender} >
                                <option>Gender</option>
                                <option value="Male">Male</option>
                                <option value="Female">Female</option>
                            </select>
                        </div>
                    </div>
                    <div className="button">
                        <input type="submit" value="Register" />
                    </div>
                </form>
            </div>
        </div>
    )
}
export default InsertChild;