import React, { useState } from "react";
import { toast } from "react-toastify";
import MainAxios from "../../redux/Action";
import HTTP_METHOD from "../../Variables/HTTPmethods"
import {ChildAPILink} from "../../Variables/APIEndPoints";


export default function UpdateChild({ records, handleCancel }) {

    const url = `${ChildAPILink}/UpdateChildById`;

    const [data, setData] = useState(records);

    const showToastMessage = (e) => { toast.success(e); }; const showToastError = (e) => { toast.error(e); }

    var d = data.dateOfBirth;
    let date = d.split("T")[0]
    data.dateOfBirth = date
    console.log(date);

    function Submit(e) {
        e.preventDefault();
        
        MainAxios(url, HTTP_METHOD.Put, data)
            .then(res => {
                if (res.results.message === "Updated_Successfull") { showToastMessage(res.results.message); }
                else { showToastError(res.results.message); }
                handleCancel()
            })
            .catch(error => {
                if (error.response.data.Message === null) {
                    showToastError(error.response.data.Message);
                }
                else {
                    PrintvalidationError(error.response.data.errors);
                };
            })
    }
    const PrintvalidationError = (obj) => {
        for (var key in obj) {
            for (let index = 0; index < obj[key].length; index++) {
                showToastError(obj[key][index]);
            }
        }
    }

    function handle(e) {
        const newdata = { ...data }
        newdata[e.target.id] = e.target.value
        setData(newdata)
    }
    return (
        <div >
            <div className="content">
                <form onSubmit={(e) => Submit(e)} action="#">
                    <div className="user-details">
                        <div className="input-box">
                            <span className="details">First Name</span>
                            <input type="text" onChange={(e) => handle(e)} id='firstName' value={data.firstName} placeholder="Enter your name" required />
                        </div>
                        <div className="input-box">
                            <span className="details">Last Name</span>
                            <input type="text" onChange={(e) => handle(e)} id='lastName' value={data.lastName} placeholder="Enter your lastname" required />
                        </div>

                        <div className="input-box">
                            <span className="details">Child ID </span>
                            <input type="number" onChange={(e) => handle(e)} id='id' value={data.id} placeholder="Enter your Register Child Id" required />
                        </div>
                        <div className="input-box">
                            <span className="details">Parent ID </span>
                            <input type="number" onChange={(e) => handle(e)} id='parentID' value={data.parentID} placeholder="Enter your before Register Parent Id" required />
                        </div>
                        <div className="input-box">
                            <span className="details">Status </span>
                            <select type='text' className="classdropdown" onChange={(e) => handle(e)} id='status' value={data.status}>
                                <option> Status</option>
                                <option value="Active">Active</option>
                                <option value="INActive">INActive</option>
                            </select>
                        </div>
                        <div className="input-box">
                            <span className="details">Gender </span>
                            <select type='text' className="classdropdown" onChange={(e) => handle(e)} id='gender' value={data.gender} >
                                <option>Gender</option>
                                <option value="Male">Male</option>
                                <option value="Female">Female</option>
                            </select>
                        </div>

                        <div className="input-box">
                            <span className="details">Date Of Birth</span>
                            {/* <DatePicker value={dayjs(data.dateOfBirth)} format={dateFormat} /> */}
                            <input type='date' onChange={(e) => handle(e)} id='dateOfBirth' value={data.dateOfBirth} required />
                        </div>
                    </div>
                    <div className="button">
                        <input type="submit" value="Update " />
                    </div>
                </form>
            </div>
        </div>
    )

};
