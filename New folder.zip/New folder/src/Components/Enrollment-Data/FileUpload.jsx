import React from "react";
import { useState } from "react";
import { toast } from 'react-toastify';
import MainAxios from "../../redux/Action";
import HTTP_METHOD from "../../Variables/HTTPmethods";
import {FileUploadAPILink} from "../../Variables/APIEndPoints";
import axios, { Axios } from "axios";
import StorageKey from "../../Variables/LocalStorageKey";

export const FileUpload = () => {

  const [FileDetails, setFile] = useState();

 
  const savefile = (e) => { console.log(e); setFile(e.target.files[0]);};
  
  const responcePass =(e) =>{ toast.success(e)};  const responceFail =(e) =>{ toast.error(e)};

  const url = `${FileUploadAPILink}/PostFile`;
  
  const Uploadfile = () => {
      // alert(FileDetails)
      console.log(FileDetails);
     const formdata = new FormData();
     formdata.append("FileDetails", FileDetails);
     formdata.append("EnrollmentId",localStorage.getItem("EnrollmentId"));
     var d = [...formdata.entries()]
     console.log(d);

     axios.post(url,formdata,
      {headers: 
        { 'Authorization': 'Bearer ' + localStorage.getItem(StorageKey.Token), 
        maxBodyLength: Infinity,
        "Content-Type": "multipart/form-data" 
      },})
     
    //  MainAxios(url,HTTP_METHOD.Post,formdata)
    //  .then(res=>responcePass(res.data.message))
    //  .catch((e)=>responceFail(e.response.data.message))
    }



  return (
    <>
      <div> <h1>Upload Image</h1>
        <input type={"file"} onChange={savefile} />
        <input type={"button"} value="upload" onClick={Uploadfile} />
      </div>
      <div> <h1>Upload BirthCertificate</h1>
        <input type={"file"} onChange={savefile} />
        <input type={"button"} value="upload" onClick={Uploadfile} />
      </div>
    </>
  )
  }