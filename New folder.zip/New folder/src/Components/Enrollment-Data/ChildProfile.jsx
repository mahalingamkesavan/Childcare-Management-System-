import { useEffect, useState } from "react";
import MainAxios from "../../redux/Action";
import HTTP_METHOD from "../../Variables/HTTPmethods";
import { EnrollmentAPILink } from "../../Variables/APIEndPoints";
import * as React from 'react';
import { Card } from "antd";
const { Meta } = Card;



export const GetChildProfile = () => {

    const url = `${EnrollmentAPILink}/GetChildProfileandParent`;

    const [data, setdata] = useState([]);

    useEffect(() => { MainAxios(url, HTTP_METHOD.Get, "").then((res) => setdata(res.childProfiles)).catch((error) => console.log(error.response.data.Message)); }, []);

    console.log(data);


    return (
        <div style={{display: "flex", flexDirection: "row",flexWrap :"wrap",}}>
        {data.map(child => {
            return (
                    <Card style={{ width: "320px", height: "230px", display: "flex", flexDirection: "column", color: "white", marginBottom: "40px", backgroundColor: "black",marginRight:"5px" }}>
                        <Meta title={<div style={{ color: 'white' }}>{child.childFirstName + " " + child.childLastName}</div>}
                            description=
                            {
                                <div>
                                    <div style={{ color: "white" }}>Date of Birth : {"\t" + child.dob.split("T")[0]} </div>
                                    <div style={{ color: "white" }}>Gender : {"\t" + child.gender}</div>
                                    <div style={{ color: "white" }}>Parent Name :{"\t" + child.parentFirstName + " " + child.parentLastName}</div>
                                    <div style={{ color: "white" }}>Email : {"\t" + child.email}</div>
                                    <div style={{ color: "white" }}>Phone NUmber :{"\t" + child.phoneNumber}</div>
                                    <div style={{ color: "white" }}>Class Starting Date :{"\t" + child.classStartingDate.split("T")[0]}</div>
                                    <div style={{ color: "white" }}>Class Ending Date :{"\t" + child.classEndingDate.split("T")[0]}</div>
                                </div>
                            }
                        />
                    </Card>
            )
        })}
        </div>

    );
}
















// import { Col, Divider, Row } from 'antd';
// const style = { background: '#0092ff', padding: '8px 0', };
// return (
//     <>
//         <Divider><h1>Child Details</h1></Divider>

//         <Row gutter={[16, 24]}>
//             <Col className="gutter-row" span={6}>
//                 <div style={style}>col-6</div>
//             </Col>
//             <Col className="gutter-row" span={6}>
//                 <div style={style}>col-6</div>
//             </Col>
//             <Col className="gutter-row" span={6}>
//                 <div style={style}>col-6</div>
//             </Col>
//             <Col className="gutter-row" span={6}>
//                 <div style={style}>col-6</div>
//             </Col>
//             <Col className="gutter-row" span={6}>
//                 <div style={style}>col-6</div>
//             </Col>
//             <Col className="gutter-row" span={6}>
//                 <div style={style}>col-6</div>
//             </Col>
//             <Col className="gutter-row" span={6}>
//                 <div style={style}>col-6</div>
//             </Col>
//             <Col className="gutter-row" span={6}>
//                 <div style={style}>col-6</div>
//             </Col>
//         </Row>
//     </>
// )
