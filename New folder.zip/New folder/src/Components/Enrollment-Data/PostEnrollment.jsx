import React, { useState } from "react";
import { toast } from "react-toastify";
import MainAxios from "../../redux/Action";
import HTTP_METHOD from "../../Variables/HTTPmethods";
import { EnrollmentAPILink } from "../../Variables/APIEndPoints";
import StorageKey from "../../Variables/LocalStorageKey";

export default function InsertEnrollment() {

    const url = `${EnrollmentAPILink}/RegistrationEnrollment`;
    console.log(url);

    const showToastMessage = (e) => { toast.success(e); }

    const ErroToastMessage = (e) => { toast.error(e); }

    const [data, setData] = useState({ enrollmentStartingDate: "", enrollmentEndinggDate: "", classname: "", slotname: "", createBy: "" })

    async function Submit(e) {

        e.preventDefault();
        await MainAxios(url, HTTP_METHOD.Post, { ...data, childID: localStorage.getItem("Child Id"), parentId: localStorage.getItem("Parent Id"), createBy: localStorage.getItem(StorageKey.Username) })
            .then(res => {
                if (res.results.message === "registration_successfull") {
                    showToastMessage(res.results.message)
                    localStorage.setItem("EnrollmentId", res.id);
                }
                else { ErroToastMessage(res.results.message); }
            }).catch(error => {
                if (error.response.data.Message === "Internal Server Error .") {
                    ErroToastMessage(error.response.data.Message);
                }
                else {
                    PrintvalidationError(error.response.data.errors);
                };
            })
    }

    const PrintvalidationError = (obj) => {
        for (var key in obj) {
            for (let i = 0; i < obj[key].length; i++) {
                ErroToastMessage(obj[key][i])
            }
        }
    }

    function handle(e) {
        const newdata = { ...data }
        newdata[e.target.id] = e.target.value
        setData(newdata)
        console.log(newdata);
    }
    return (
        <div className="container">
            <div style={{ textAlign: "center" }}>
                <img
                    width={250}
                    src="https://1coresolution.com/images/1corelogo-opti.png" />
            </div>
            <div className="title">Registration Enrollment</div>
            <div className="content">
                <form onSubmit={(e) => Submit(e)} action="#">
                    <div className="user-details">
                        <div className="input-box">
                            <span className="details">class Starting Date</span>
                            <input type="date" onChange={(e) => handle(e)} id="enrollmentStartingDate" value={data.entrollmentStartingDate} required />
                        </div>
                        <div className="input-box">
                            <span className="details">class Entding Date </span>
                            <input type="date" id="enrollmentEndinggDate" value={data.entrollmentEndinggDate} onChange={(e) => handle(e)} required />
                        </div>
                        <div className="input-box">
                            <span className="details">class Name </span>
                            <select type='text' className="classdropdown" onChange={(e) => handle(e)} id='classname' value={data.classNamename} >
                                <option> class Name</option>
                                <option value="A">A</option>
                                <option value="B">B</option>
                                <option value="C">C</option>
                                <option value="D">D</option>
                            </select>
                        </div>
                        <div className="input-box">
                            <span className="details">Slot Name </span>
                            <select type='text' className="classdropdown" onChange={(e) => handle(e)} id='slotname' value={data.slotname} >
                                <option> Slot Name</option>
                                <option value="A1">A1</option>
                                <option value="A2">A2</option>
                                <option value="B1">B1</option>
                                <option value="B2">B2</option>
                                <option value="C1">C1</option>
                                <option value="C2">C2</option>
                                <option value="D1">D1</option>
                                <option value="D2">D2</option>
                            </select>
                        </div>
                    </div>
                    <div className="button">
                        <input type="submit" value="Register" />
                    </div>

                </form>
            </div>
        </div>
    )
}