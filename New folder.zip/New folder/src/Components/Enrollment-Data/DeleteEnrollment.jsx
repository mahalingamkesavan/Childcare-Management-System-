import { Button, Modal } from 'antd';
import { useState, memo } from 'react';
import {  toast } from 'react-toastify';
import MainAxios from "../../redux/Action";
import HTTP_METHOD from "../../Variables/HTTPmethods";
import {EnrollmentAPILink} from "../../Variables/APIEndPoints";

const DeleteEnrollment = ({ record, records }) => {

  const [isModalOpen, setIsModalOpen] = useState(false);

  const responceSuccess = (e) => { toast.success(e) }; const responceError = (e) => { toast.error(e) }

  const showModal = () => { setIsModalOpen(true); };

  const handleOk = () => {

    if (localStorage.getItem("Role") === "Admin") {
      const url = `${EnrollmentAPILink}/DeleteEnrollmentById?id=${records.id}`;

      MainAxios(url,HTTP_METHOD.Delete,"")
        .then(res => {
          if (res.results.message === "Delete_Successfull") {
              responceSuccess(res.results.message)
              window.location.reload();
          }
        }).catch((e) => responceError(e.response.data.Message));
    }
    else { responceError("Your Con't Access,Contact Admin....") }
    setIsModalOpen(false);
  };

  const handleCancel = () => { setIsModalOpen(false); };

  return (
    <>
    
      <Button type="primary" onClick={showModal}> Delete </Button>
      <Modal title="Delete Confirmation " open={isModalOpen} onOk={handleOk} onCancel={handleCancel}>
        <h2>Are you sure delete this task?..</h2>
      </Modal>
    </>
  );
};
export default memo(DeleteEnrollment);