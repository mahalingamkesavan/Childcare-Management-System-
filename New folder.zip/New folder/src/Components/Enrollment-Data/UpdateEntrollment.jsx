import { useState, memo } from "react";
import { toast } from "react-toastify";
import MainAxios from "../../redux/Action";
import HTTP_METHOD from "../../Variables/HTTPmethods";
import {EnrollmentAPILink} from "../../Variables/APIEndPoints";

export default function UpdateEnrollment({ records, handleCancel }) {

    const url = `${EnrollmentAPILink}/UpdateEnrollmentById`;

    const showToastMessage = (e) => { toast.success(e); }; const ErrorToastMessage = (e) => { toast.error(e); };

    const [data, setData] = useState(records);

    var d = data.enrollmentStartingDate;
    let date1 = d.split("T")[0];
    data.enrollmentStartingDate = date1;

    var d = data.enrollmentEndinggDate;
    let date = d.split("T")[0];
    data.enrollmentEndinggDate = date;

    function Submit(e) {
        e.preventDefault();
        MainAxios(url, HTTP_METHOD.Put, { ...data, createBy: localStorage.getItem("Username"), })
            .then((res) => {
                if (res.results.message === "Updated_Successfull") {
                    showToastMessage(res.results.message);
                    window.location.reload();
                } else {
                    ErrorToastMessage(res.results.message);
                }
                handleCancel();
            })
            .catch((error) => {
                if (error.response.data.Message === null) {
                    ErrorToastMessage(error.response.data.Message);
                }
                else {
                    PrintvalidationError(error.response.data.errors);
                }
            });
    }
    const PrintvalidationError = (obj) => {
        for (var key in obj) {
            for (let i = 0; i < obj[key].length; i++) {
                ErrorToastMessage(obj[key][i])
            }
        }
    }

    function handle(e) {
        const newdata = { ...data };
        newdata[e.target.id] = e.target.value;
        setData(newdata);
    }
    
    return (
        <div className="content">

            <form onSubmit={(e) => Submit(e)} action="#">
                <div className="user-details">
                    <div className="input-box">
                        <span className="details">Enrollment ID</span>
                        <input
                            type="text"
                            onChange={(e) => handle(e)}
                            id="id"
                            value={data.id}
                            placeholder="Enter your Enrollment Id"
                            required
                        />
                    </div>
                    <div className="input-box">
                        <span className="details">Child ID</span>
                        <input
                            type="number"
                            onChange={(e) => handle(e)}
                            id="childID"
                            value={data.childID}
                            placeholder="Enter your before Child Id"
                            required
                        />
                    </div>
                    <div className="input-box">
                        <span className="details">Parent Id</span>
                        <input
                            type="number"
                            onChange={(e) => handle(e)}
                            id="parentId"
                            value={data.parentId}
                            placeholder="Enter your before Parent Id"
                            required
                        />
                    </div>
                    <div className="input-box">
                        <span className="details">Class Starting Date</span>
                        <input
                            type="date"
                            onChange={(e) => handle(e)}
                            id="enrollmentStartingDate"
                            value={data.enrollmentStartingDate}
                            required
                        />
                    </div>
                    <div className="input-box">
                        <span className="details">Class Enting Date </span>
                        <input
                            type="date"
                            id="enrollmentEndinggDate"
                            value={data.enrollmentEndinggDate}
                            onChange={(e) => handle(e)}
                            required
                        />
                    </div>
                    <div className="input-box">
                        <span className="details">Class Name </span>
                        <select
                            type="text"
                            className="classdropdown"
                            onChange={(e) => handle(e)}
                            id="classname"
                            value={data.classname}
                        >
                            <option> className</option>
                            <option value="A">A</option>
                            <option value="B">B</option>
                            <option value="C">C</option>
                            <option value="D">D</option>
                        </select>
                    </div>
                    <div className="input-box">
                        <span className="details">Slot Name </span>
                        <select
                            type="text"
                            className="classdropdown"
                            onChange={(e) => handle(e)}
                            id="slotname"
                            value={data.slotname}
                        >
                            <option> Slot Name</option>
                            <option value="A1">A1</option>
                            <option value="A2">A2</option>
                            <option value="B1">B1</option>
                            <option value="B2">B2</option>
                            <option value="C1">C1</option>
                            <option value="C2">C2</option>
                            <option value="D1">D1</option>
                            <option value="D2">D2</option>
                        </select>
                    </div>
                </div>
                <div className="button">
                    <input type="submit" value="Update" />
                </div>
            </form>
        </div>
    );
}
