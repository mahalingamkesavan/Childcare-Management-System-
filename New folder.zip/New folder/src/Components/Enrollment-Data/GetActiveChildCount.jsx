import { useEffect, useState } from 'react'
import MainAxios from "../../redux/Action";
import HTTP_METHOD from "../../Variables/HTTPmethods";
import {EnrollmentAPILink} from "../../Variables/APIEndPoints";

function GetActiveChildCount() {

  const [childcount,setvalue]=useState(''); const url=`${EnrollmentAPILink}/GetActiveChildCount`;

   useEffect(() => { MainAxios(url,HTTP_METHOD.Get,"").then(result =>setvalue(result)).catch((error)=>console.log(error)); })

   return childcount
  
}

export default GetActiveChildCount
