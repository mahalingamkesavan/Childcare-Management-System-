import { toast } from "react-toastify";
import MainAxios from "../../redux/Action";
import HTTP_METHOD from "../../Variables/HTTPmethods";
import { EnrollmentAPILink } from "../../Variables/APIEndPoints";


export default async function EnrollmentApproval(records, status) {

    const url = `${EnrollmentAPILink}/EnrollmentApproval_Admin`;

    const data = records;
    console.log(records);
    console.log(status);

    const showToastMessage = (e) => { toast.success(e); }; const ErrorToastMessage = (e) => { toast.error(e); };

    MainAxios(url, HTTP_METHOD.Put, { ...data, CreateBy: localStorage.getItem("Username"), Admission_Approveby: localStorage.getItem("Username"), AdmissionStatus: status })
        .then((res) => {
            console.log(res);
            if (res.results.message === "Updated_Successfull") {
                showToastMessage(res.results.message);
                window.location.reload();
            } else {
                ErrorToastMessage(res.results.message);
            }
        }).catch(error => {
            if (error.response.data.Message === "Internal Server Error .") {
                ErrorToastMessage(error.response.data.Message);
            }
            else {
                PrintvalidationError(error.response.data.errors);
            };
        })
    const PrintvalidationError = (obj) => {
        for (var key in obj) {
            for (let i = 0; i < obj[key].length; i++) {
                ErrorToastMessage(obj[key][i])
            }
        }
    }
}