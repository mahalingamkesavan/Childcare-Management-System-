import React, { useEffect, useState } from 'react';
import { Col, Input, Row, Space, Table } from 'antd';
import DeleteEnrollment from "./DeleteEnrollment"
import UpdatePopup from "./UpdatePopup";
import * as moment from "moment";
import { useDispatch } from 'react-redux';
import { GetEnrollment } from "../../Features/EnrollmentServicess";

export const GetEnrollmentList = () => {

    const [GetEntrollment, SetEntrollment] = useState([]);
    const [value, setValue] = useState('');
    const [dataSource, setDataSource] = useState([]);

    var disPatch = useDispatch();


    useEffect(() => { GetEnrollment(disPatch).then((res) => SetEntrollment(res)); }, [])

    useEffect(() => { if (GetEntrollment.length > 0) setDataSource(GetEntrollment); }, [GetEntrollment])

    return (
        <div>
            <input
                placeholder="Search Class Name ....."
                value={value}
                onChange={(e) => {
                    const currValue = e.target.value;
                    setValue(currValue);
                    const filteredData = GetEntrollment.filter(entry => entry.classname.toLowerCase().includes(currValue));
                    setDataSource(filteredData);
                }}
                style={{ marginBottom: 15,width:"200px" }}
            />
            <Table rowKey={record => record.id} columns={columns} dataSource={dataSource} />
        </div>)
}



const columns = [
    { title: 'Enrollment_ID', dataIndex: 'id', key: 'id', },
    { title: 'child_ID', dataIndex: 'childID', key: 'childID', },
    { title: 'Parent_Id', dataIndex: 'parentId', key: 'parentId', },
    { title: ' joining_Date', key: 'enrollmentStartingDate', dataIndex: 'enrollmentStartingDate', render: (record) => (<span>{moment(record).format("DD-MM-YYYY")}</span>) },
    { title: ' Ending_Date', key: 'enrollmentEndinggDate', dataIndex: 'enrollmentEndinggDate', render: (record) => (<span>{moment(record).format("DD-MM-YYYY")}</span>) },
    { title: 'Class_Name', key: 'classname', dataIndex: 'classname', },
    { title: 'Slot_Name', key: 'slotname', dataIndex: 'slotname', },
    { title: 'CreateBy', key: 'createBy', dataIndex: 'createBy', },
    { title: 'CreateDate', key: 'createDate', dataIndex: 'createDate', },
    { title: 'UpdateBy', key: 'updateBy', dataIndex: 'updateBy', },
    { title: 'UpdateDate', key: 'updateDate', dataIndex: 'updateDate', },
    {
        title: 'Action', render: (record, records) => {
            return (
                <Row>
                    <Space size={8}>
                        <Col span={12}>
                            {localStorage.getItem("Role") === "Admin" && <DeleteEnrollment records={records} />}
                        </Col>
                        <Col span={12}>
                            <UpdatePopup records={records} />
                        </Col>
                    </Space>
                </Row>)
        }
    }
];
