import React, { useState } from "react";
import MainAxios from "../../redux/Action";
import HTTP_METHOD from "../../Variables/HTTPmethods"
import { toast } from "react-toastify";
import {ParentAPILink} from "../../Variables/APIEndPoints"

function UpdateParent({ records, handleCancel }) {

    const url = `${ParentAPILink}/UpdateParentById`;

    const SuccessMessage = (e) => { toast.success(e) }; const ErroMassage = (e) => { toast.error(e) };

    const [data, setData] = useState(records)

    function Submit(e) {
        e.preventDefault();
        MainAxios(url, HTTP_METHOD.Put, data)
            .then(res => {
               
                if (res.results.message === "Updated_Successfull") { SuccessMessage(res.results.message); window.location.reload(); }
               
                else { ErroMassage(res.results.message); }
               
                handleCancel()
            })
            .catch(error => {

                if (error.response.data.Message === null) { ErroMassage(error.response.data.Message); }
               
                else { PrintvalidationError(error.response.data.errors); }
            })
    }

    const PrintvalidationError = (obj) => {
        for (var key in obj) {
            for (let i = 0; i < obj[key].length; i++) {
                ErroMassage(obj[key][i])
            }
        }
    }

    function handle(e) {
        const newdata = { ...data }
        newdata[e.target.id] = e.target.value
        setData(newdata)
    }

    return (
        <div>
            <div className="content">
                <form onSubmit={(e) => Submit(e)} action="#">
                    <div className="user-details">
                        <div className="input-box">
                            <span className="details">First Name</span>
                            <input type="text" onChange={(e) => handle(e)} id="firstName" value={data.firstName} placeholder="Enter your name" required />
                        </div>
                        <div className="input-box">
                            <span className="details">Last Name</span>
                            <input type="text" onChange={(e) => handle(e)} id="lastName" value={data.lastName} placeholder="Enter your lastname" required />
                        </div>
                        <div className="input-box">
                            <span className="details">Email</span>
                            <input type="email" onChange={(e) => handle(e)} id="email" value={data.email} placeholder="Enter your email" required />
                        </div>
                        <div className="input-box">
                            <span className="details">Phone Number</span>
                            <input type="number" onChange={(e) => handle(e)} id="phoneNumber" value={data.phoneNumber} placeholder="Enter your number" required />
                        </div>
                        <div className="input-box">
                            <span className="details">Parent ID </span>
                            <input type="number" id="id" value={data.id} onChange={(e) => handle(e)} placeholder="Enter your Register Parent Id" required />
                        </div>
                        <div className="input-box">
                            <span className="details">Status </span>
                            <select type='text' className="classdropdown" onChange={(e) => handle(e)} id='status' value={data.status} placeholder='status' >
                                <option> Status</option>
                                <option value="Active">Active</option>
                                <option value="INActive">INActive</option>
                            </select>
                        </div>
                    </div>
                    <div className="button">
                        <input type="submit" value="Update" />
                    </div>
                </form>
            </div>
        </div>
    )
}

export default UpdateParent;
