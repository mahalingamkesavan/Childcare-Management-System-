import React, { useEffect, useState } from "react";
import { Col, Input, Row, Space, Table } from "antd";
import DeleteParent from "./DeleteParent";
import UpdateParentModal from "./UpdatePopupParent";
import { useNavigate } from "react-router-dom";
import {GetParentList} from "../../Features/ParentServicess";
import { useDispatch } from "react-redux";

export const ParentComponent = () => {
  
  const columns = [
    {
      title: "ParentID #", dataIndex: "id",  key: "id",
      render: (record) => (<label onClick={() => historyOfChild(`/GetParentChild/${record}`)}> {record} </label> ),
    },
    { title: "PhoneNumber", dataIndex: "phoneNumber",key: "phoneNumber",},
    { title: "Email", dataIndex: "email", key: "email" },
    { title: "First Name", key: "firstName", dataIndex: "firstName" },
    { title: "Last Name", key: "lastName", dataIndex: "lastName" },
    { title: "Status", key: "status", dataIndex: "status" },
    {
      title: "Actions",
      render: (record, records) => {
        return (
          <Row>
            <Space size={10}>
              <Col span={12}>
                {localStorage.getItem("Role") === "Admin" && (<DeleteParent records={records} /> )}
              </Col>
              <Col span={12}>
                <UpdateParentModal records={records} />
              </Col>
            </Space>
          </Row>
        );
      },
    },
  ];

  const [GetParent, setparent] = useState([]);  const [value, setValue] = useState('');

  const [dataSource, setDataSource] = useState([]);  const disPatch=useDispatch(); 
  
  const historyOfChild = useNavigate();

  useEffect(()=>{ GetParentList(disPatch).then((res)=>setparent(res));  },[]);

  useEffect(() => { if(GetParent.length>0){ setDataSource(GetParent) } }, [GetParent]);
  
  return (
    <div>
       <input
        placeholder="Search Name ....."
        value={value}
        onChange={(e) => {
        const currValue = e.target.value;
        setValue(currValue);
        const filteredData = GetParent.filter(entry =>(entry.firstName.toLowerCase()||entry.firstName.toUpperCase()).includes(currValue));
        setDataSource(filteredData);
      }}
      style={{marginBottom:8,width:"200px"}}
    />
      <Table rowKey={(record) => record.id} columns={columns} dataSource={dataSource}/>

    </div>
  );
};





















// import MainAxios from "../../redux/Action";
// import HTTP_METHOD from "../../Variables/HTTPmethods"
  // // const url = "https://localhost:7232/Parent/GetParentList";

  // useEffect(()=>{ 

  //   // MainAxios(url,HTTP_METHOD.Get,"").then((res) => setparent(res.parent)).catch((e)=>(e.response.data.Message))
  
  // },[]);