import './Parent.css';
import { useNavigate } from 'react-router-dom';
import React, { useState } from "react";
import { RegisterParent } from "../../Features/ParentServicess";

function InsertParent() {

  const [data, setData] = useState({ firstName: '', lastName: '', status: '', phoneNumber: '', email: '' })

  const nav = useNavigate();
  async function Submit(e) {
    e.preventDefault();
    var responce = await RegisterParent(data);
    console.log(responce);
    if (responce === "registration_successfull") {
      setTimeout(() => { nav("/PostChild") }, 4000);
    }
  }

  function handle(e) {
    const newdata = { ...data }
    newdata[e.target.id] = e.target.value
    setData(newdata)
  }
  return (
    <div className="container">
      <div style={{ textAlign: "center" }}>
        <img
          width={250}
          src="https://1coresolution.com/images/1corelogo-opti.png" />
      </div>
      <div className="title">Registration Parent</div>
      <div className="content">
        <form onSubmit={(e) => Submit(e)} action="#">

          <div className="user-details">
            <div className="input-box">
              <span className="details">First Name</span>
              <input type="text" onChange={(e) => handle(e)} id="firstName" value={data.firstName} placeholder="Enter your name" required />
            </div>
            <div className="input-box">
              <span className="details">Last Name</span>
              <input type="text" onChange={(e) => handle(e)} id="lastName" value={data.lastName} placeholder="Enter your lastname" required />
            </div>
            <div className="input-box">
              <span className="details">Email</span>
              <input type="email" onChange={(e) => handle(e)} id="email" value={data.email} placeholder="Enter your email" required />
            </div>
            <div className="input-box">
              <span className="details">Phone Number</span>
              <input type="number" onChange={(e) => handle(e)} id="phoneNumber" value={data.phoneNumber} placeholder="Enter your number" required />
            </div>
            <div className="input-box">
              <span className="details">Status </span>
              <select type='text' className="classdropdown" onChange={(e) => handle(e)} id='status' value={data.status} placeholder='status' >
                <option> Status</option>
                <option value="Active">Active</option>
                <option value="INActive">INActive</option>
              </select>
            </div>
          </div>
          <div className="button">
            <div>
               <input type="submit" value="Register" />  <input type="submit" value="Next" />
            </div>
            
          </div>
        </form>
      </div>
    </div>
  )
}

export default InsertParent;























// import MainAxios from "../../redux/Action";
// import HTTP_METHOD from "../../Variables/HTTPmethods";
// import RegisterParent from "../../Features/ParentServicess";
  // const url = 'https://localhost:7232/Parent/RegistrationParent'

  // const nav = useNavigate();

  // const SuccessMessage = (e) => { toast.success(e) }; const ErroMassage = (e) => { toast.error(e) };


 // const PrintvalidationError = (obj) => {
  //   for (var key in obj) {
  //     for (let i = 0; i < obj[key].length; i++) {
  //       ErroMassage(obj[key][i])
  //     }
  //   }
  // }
  // MainAxios(url, HTTP_METHOD.Post, data)
    //   .then(res => {
    //     if (res.results.message === "registration_successfull") {
    //       SuccessMessage(res.results.message)
    //       localStorage.setItem("Parent Id", res.id);
    //       setTimeout(() => { nav("/PostChild") }, 4000);
    //     }
    //     else { ErroMassage(res.results.message); }
    //   }).catch((error) => {
    //     if (error.response.data.Message === "Internal Server Error.") {
    //       ErroMassage(error.response.data.Message);
    //     }
    //     else {
    //       PrintvalidationError(error.response.data.errors);
    //     }

    //   })