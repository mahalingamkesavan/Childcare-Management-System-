import { Button, Modal } from 'antd';
import { useState } from 'react';
import { toast } from 'react-toastify';
import MainAxios from "../../redux/Action";
import HTTP_METHOD from "../../Variables/HTTPmethods";
import {ParentAPILink} from "../../Variables/APIEndPoints"

const DeleteParent = ({ record, records }) => {

  const { id, createBy } = records || {};

  const [isModalOpen, setIsModalOpen] = useState(false); 
  
  const showModal = () => { setIsModalOpen(true); }; const handleCancel = () => { setIsModalOpen(false); };

  const responce = (e) => { toast.success(e) }; const errorresponce = (e) => { toast.error(e) }

  const handleOk = () => {
    if (localStorage.getItem("Role") === "Admin") {

      const url = `${ParentAPILink}/DeleteParentById?id=${records.id}`;

      MainAxios(url,HTTP_METHOD.Delete,"")
        .then(res => {
                if (res.results.message === "Delete_Successfull") {
                  responce(res.results.message)
                  window.location.reload(false)
                }
                else { errorresponce(res.results.message) }
       
        }).catch((e) => errorresponce(e.response.data.Message))
    }
    else { responce("Your Con't Access,Contact Admin....") }
    setIsModalOpen(false);
  };

  return (
    <>
      <Button type="primary" onClick={showModal}> Delete </Button>
      <Modal title="Delete Confirmation " open={isModalOpen} onOk={handleOk} onCancel={handleCancel}>
        <p>Are you sure delete this task?..</p>
      </Modal>
    </>
  );
};

export default DeleteParent;
