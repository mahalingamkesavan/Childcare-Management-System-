import React from 'react';


const createParentUser = () => {

    const [data, setData] = useState({ Username: '', Email: '', Password: '' })

    async function Submit(e) {   e.preventDefault();    await CreateAdmin(data);  }

    function handle(e) 
    {
        const newdata = { ...data }
        newdata[e.target.id] = e.target.value
        setData(newdata)
    }

    return (
        <div>

        </div>
    )
}

export default createParentUser
