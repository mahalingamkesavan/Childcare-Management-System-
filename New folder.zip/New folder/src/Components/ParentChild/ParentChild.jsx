import axios from "axios";
import React, { useEffect, useState } from "react";
import { Table } from "antd";
import { useParams } from "react-router-dom";
import MainAxios from '../../redux/Action';
import HTTP_METHOD from "../../Variables/HTTPmethods";

import moment from "moment";
const GetParentChild = () => {
  const { Id } = useParams()
  const [parentchild, setparentchildrelation] = useState();
  const { parent, childList } = parentchild || {}

  const url = `https://localhost:7232/ParentChilld/GetParentChildRelationship?id=${Id}`;

  useEffect(() => { MainAxios(url, HTTP_METHOD.Get,"").then(res => setparentchildrelation(res.parentChildData)) }, [Id])

  const parentname = parent?.firstName
  return (
    <div>
      <div style={{ textAlign: "center" }}>
        <h2>Parent Details</h2>
        <div>
          <h1>Parent Name :{parentname}</h1>
        </div>
      </div>
      <div style={{ textAlign: "center" }}>
        <h2>Child Details</h2>
        <Table rowKey={record => record.id} columns={columns} dataSource={childList} />
      </div>
    </div>);
}
const columns = [
  { title: 'First Name', dataIndex: 'firstName', key: 'firstName', },
  { title: 'Last Name', dataIndex: 'lastName', key: 'lastName', },
  { title: 'Child Id', dataIndex: 'id', key: 'id', },
  { title: 'Parent ID', dataIndex: 'parentID', key: 'parentID', },
  { title: 'Gender', dataIndex: 'gender', key: 'gender', },
  { title: 'Date Of Birth', dataIndex: 'dateOfBirth', key: 'dateOfBirth', render: (record) => (<span>{moment(record).format("DD-MM-YYYY")}</span>) },
  { title: "Status", dataIndex: "status", key: "status", },
];
export default GetParentChild;







