import React, { useState } from "react";
import { CreateAdmin } from "../../Features/Authservicess";


function AdminSingUp() {

    const [data, setData] = useState({ Username: '', Email: '', Password: '' })

    async function Submit(e) {
        e.preventDefault();
        await CreateAdmin(data);
    }

    function handle(e) {
        const newdata = { ...data }
        newdata[e.target.id] = e.target.value
        setData(newdata)
    }


    return (
        <div className="bodyContainer">
            <div className="container">
                <div style={{ textAlign: "center" }}>
                    <img
                        width={250}
                        src="https://1coresolution.com/images/1corelogo-opti.png" />
                </div>
                <div className="title"> Admin Registration </div>
                <div className="content">
                    <form onSubmit={(e) => Submit(e)} action="#">
                        <div className="user-details">
                            <div className="input-box">
                                <span className="details">Username</span>
                                <input type="text" onChange={(e) => handle(e)} id="Username" value={data.Username} placeholder="Enter your Username" required />
                            </div>
                            <div className="input-box">
                                <span className="details">Email</span>
                                <input onChange={(e) => handle(e)} id="Email" value={data.Email} placeholder="Email" type='Email'></input>
                            </div>
                            <div className="input-box">
                                <span className="details">Passward</span>
                                <input type="passward" onChange={(e) => handle(e)} id="Password" value={data.Password} placeholder="Enter your Password" />
                            </div>
                        </div>
                        <div className="button">
                            <input type="submit" value="Register" />
                        </div>
                    </form>
                </div>
            </div>
        </div>
    )

}
export default AdminSingUp;