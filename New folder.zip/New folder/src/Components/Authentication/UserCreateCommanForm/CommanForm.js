import { Form, Button, Checkbox, DatePicker, Input, Select } from "antd";

import React from 'react'

const CommanForm = () => {

    return (
        <div>

        </div>
    )
}

export default CommanForm
