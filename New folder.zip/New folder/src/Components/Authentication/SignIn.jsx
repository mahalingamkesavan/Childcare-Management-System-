import React, { useState,useEffect } from "react";
import { useDispatch } from "react-redux";
import { Link } from 'react-router-dom';
import { useNavigate } from "react-router-dom";
import {LoginData} from "../../Features/Authservicess"
import StorageKey from "../../Variables/LocalStorageKey";

function SingIn() 
{
   
    const disPatch = useDispatch();const nav = useNavigate();
   
    const [data, setData] = useState({ Username: '', Password: '' })

    async function  Submit (e) 
    {
        e.preventDefault();
        await LoginData(data,disPatch);
        if(localStorage.getItem(StorageKey.Token)!==null)
        { 
            nav("/home");
        }
    }

    function handle(e) {
        const newdata = { ...data }
        newdata[e.target.id] = e.target.value
        setData(newdata)
    }
    
    return (
        <div className="bodyContainer">
            <div className="container">
                <div style={{ textAlign: "center" }}>
                    <img
                        width={250}
                        src="https://1coresolution.com/images/1corelogo-opti.png" />
                </div>
                <div className="title">Login</div>
                <div className="content">
                    <form onSubmit={(e) => Submit(e)} action="#">
                        <div className="user-details">
                            <div className="input-box">
                                <span className="details">Username</span>
                                <input type="text" onChange={(e) => handle(e)} id="Username" value={data.Username} placeholder="Enter your Username" required />
                            </div>
                            <div className="input-box">
                                <span className="details">Password</span>
                                <input type="password" onChange={(e) => handle(e)} id="Password" required value={data.Password} placeholder="Enter your Password" />
                            </div>
                            <div className="input-box">
                                <Link to={"../SignUp"}>{"Don't have an account? Creat One"}</Link>
                            </div>
                            <div className="input-box">
                                <Link to={"../SignUp"}>{"forgot password ?"}</Link>
                            </div>
                        </div>
                        <div className="button">
                            <input type="submit" value="login" />
                        </div>
                    </form>
                </div>
            </div>
        </div>
    )

}
export default SingIn;

























































//     const url = "https://localhost:7159/Account/login" 
//      const nav = useNavigate();

//     //  const disPatch = useDispatch();
    
//     const [data, setData] = useState({ Username: '', Password: '' })

//     const ErroMessage = (e) => { toast.error(<h5>{e}</h5>); }

//     function Submit(e) {
//         e.preventDefault();
//         // GetToken(JSON.stringify(data),disPatch);
//         axios.post(url, { ...data })
//             .then(res => {
//                 localStorage.setItem("Token", res.data.token); localStorage.setItem("Role", res.data.roles);
//                 localStorage.setItem("Username", res.data.username)
//                 nav("/home");
//             })
//             .catch(res => { ErroMessage(res.response.data.message)})
//     }
//     function handle(e) {
//         const newdata = { ...data }
//         newdata[e.target.id] = e.target.value
//         setData(newdata)
//     }
//     return (
//         <div className="bodyContainer">
          
//             <div className="container">
//                 <div style={{ textAlign: "center" }}>
//                     <img
//                         width={250}
//                         src="https://images.socialwelfare.library.vcu.edu/files/theme_uploads/055614654318a14206b9d2aa7d5323cf.png" />
//                 </div>
//                 <div className="title">Login</div>
//                 <div className="content">
//                     <form onSubmit={(e) => Submit(e)} action="#">
//                         <div className="user-details">
//                             <div className="input-box">
//                                 <span className="details">Username</span>
//                                 <input type="text" onChange={(e) => handle(e)} id="Username" value={data.Username} placeholder="Enter your Username" required />
//                             </div>
//                             <div className="input-box">
//                                 <span className="details">Password</span>
//                                 <input type="password" onChange={(e) => handle(e)} id="Password" required value={data.Password} placeholder="Enter your Password" />
//                             </div>
//                             <div className="input-box">
//                                 <Link to={"../SignUp"}>{"Don't have an account? Creat One"}</Link>
//                             </div>
//                             <div className="input-box">
//                                 <Link to={"../SignUp"}>{"forgot password ?"}</Link>
//                             </div>
//                         </div>
//                         <div className="button">
//                             <input type="submit" value="login" />
//                         </div>
//                     </form>
//                 </div>
//             </div>
//         </div>
//     )
// }
// export default SingIn;